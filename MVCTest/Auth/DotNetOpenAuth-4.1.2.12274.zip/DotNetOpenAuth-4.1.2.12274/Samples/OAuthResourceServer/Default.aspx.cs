﻿namespace OAuthResourceServer {
	using System;
	using System.Configuration;
	using System.IO;

	using Code;

	public partial class _Default : System.Web.UI.Page {
	}
}