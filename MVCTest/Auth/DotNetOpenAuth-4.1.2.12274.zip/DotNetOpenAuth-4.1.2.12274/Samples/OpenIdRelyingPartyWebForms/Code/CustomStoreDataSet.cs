﻿namespace OpenIdRelyingPartyWebForms.Code {
	public partial class CustomStoreDataSet {
	}
}
