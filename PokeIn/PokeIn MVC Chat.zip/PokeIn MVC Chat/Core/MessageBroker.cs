﻿using System.Collections.Generic;

namespace PokeInMVC_Chat.Core
{
    public class MessageBroker
    { 

        public static void OnClientConnected(string clientId, ref Dictionary<string, object> list)
        {
            list.Add("Chat", new PubSubNotification(clientId));
        }


    }
}