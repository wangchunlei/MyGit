/*
 * PokeIn ASP.NET Ajax Library - WCF Desktop Controller Sample
 * 
 * PokeIn 2010
 * http://pokein.com
 */

Instructions:

1 - Compile Solution
2 - Run the desktop application under PokeIn WCF Sample\Server folder
3 - Run ASP.NET Web Application

